#include "Elevator.h"

Elevator::Elevator(int id){
    this->id = id;
    this->isMoving = false;
    this->weightCapacity = 2000;
    this->currentWeight = 0;
    this->direction = "idle";
    this->displayMessage = "";
    this->emergencyDisplay = "";
    this->floorNumber = rand() % 5;
    this->doorObstacleCount = 0;

    this->doorOpen = false;
    this->doorClosing = false;
    this->proscessing_request = false;
    this->doorObstacle = false;
    this->overloadDetected = false;
    this->helpButtonPressed = false;
}

int Elevator::getFloorNumber(){
    return this->floorNumber;
}

bool& Elevator::doorObstacleDetected(){
    return doorObstacle;
}
bool& Elevator::getOverloadDetected(){
    return overloadDetected;
}

string& Elevator::getDisplayMessage(){
    return displayMessage;
}

string Elevator::listPassengers(){
    string passengersList="Passengers: ";
    for(int i=0; i<int(passengers.size()); ++i){
        passengersList = passengersList+"P"+to_string(passengers[i].getId())+", ";
    }
    return passengersList;
}

string Elevator::getDirection(){
    return this->direction;
}

bool Elevator::hasRequest(){
    return requests.size()!=0;
}

bool Elevator::isThereAPassengerInElevator(){
    return passengers.size()!=0;
}

void Elevator::addRequest(Request request){
    bool requestAdded = false;
    if(request.getRequestType()=="floor"){
        if(request.getDirection()=="up"){
            if(this->direction=="idle"){
                requests.push_back(request);
                if(request.getFloorNumber()>=this->floorNumber){
                    this->direction="up";
                    requestAdded = true;
                }
                else if(request.getFloorNumber()<this->floorNumber){
                    this->direction="down";
                    requestAdded = true;
                }
            }
            else if(this->direction=="up"){
                int insertIndex=0;
                for(;insertIndex<=int(requests.size()); ++insertIndex){
                    if(insertIndex==int(requests.size())){
                        requests.push_back(request);
                        requestAdded = true;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()==request.getFloorNumber()){
                        cout<<"Floor already requested"<<endl;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()>request.getFloorNumber()){
                        requests.insert(requests.begin()+insertIndex, request);
                        requestAdded = true;
                        break;
                    }
                }
            }
        }
        else if(request.getDirection()=="down"){
            if(this->direction=="idle"){
                requests.push_back(request);
                if(request.getFloorNumber()<=this->floorNumber){
                    this->direction="down";
                    requestAdded = true;
                }
                else if(request.getFloorNumber()>this->floorNumber){
                    this->direction="up";
                    requestAdded = true;
                }
            }
            else if(this->direction=="down"){
                int insertIndex=0;
                for(;insertIndex<=int(requests.size()); ++insertIndex){
                    if(insertIndex==int(requests.size())){
                        requests.push_back(request);
                        requestAdded = true;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()==request.getFloorNumber()){
                        cout<<"Floor already requested"<<endl;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()<request.getFloorNumber()){
                        requests.insert(requests.begin()+insertIndex, request);
                        requestAdded = true;
                        break;
                    }
                }
            }
        }
    }
    else if(request.getRequestType()=="elevator"){
        if(request.getDirection()=="up"){
            if(direction=="idle"){
                direction="up";
                requests.push_back(request);
                requestAdded = true;
            }
            else if(direction=="up"){
                int insertIndex=0;
                for(;insertIndex<=int(requests.size()); ++insertIndex){
                    if(insertIndex==int(requests.size())){
                        requests.push_back(request);
                        requestAdded = true;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()==request.getFloorNumber()){
                        cout<<"Floor already requested"<<endl;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()>request.getFloorNumber()){
                        requests.insert(requests.begin()+insertIndex, request);
                        requestAdded = true;
                        break;
                    }
                }
            }
        }
        else if(request.getDirection()=="down"){
            if(direction=="idle"){
                direction="down";
                requests.push_back(request);
                requestAdded = true;
            }
            else if(this->direction=="down"){
                int insertIndex=0;
                for(;insertIndex<=int(requests.size()); ++insertIndex){
                    if(insertIndex==int(requests.size())){
                        requests.push_back(request);
                        requestAdded = true;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()==request.getFloorNumber()){
                        cout<<"Floor already requested"<<endl;
                        break;
                    }
                    else if(requests[insertIndex].getFloorNumber()<request.getFloorNumber()){
                        requests.insert(requests.begin()+insertIndex, request);
                        requestAdded = true;
                        break;
                    }
                }
            }
        }
    }
    if(requestAdded){
        cout<<"Request added to elevator!"<<endl;
        displayMessage = "Floor "+to_string(request.getFloorNumber())+" Request added to elevator!";
//        cout<<requests.size()<<endl;
//        cout<<hasRequest()<<endl;
    }
}

bool& Elevator::proscessingRequest(){
    return proscessing_request;
}

void Elevator::receivePassenger(Passenger passengers){
    this->passengers.push_back(passengers);
}

Passenger Elevator::findPassenger(int id){
    for(int i=0; i<int(passengers.size()); ++i){
        if(id==passengers[i].getId()){
            return passengers[i];
        }
    }
    cout<<"Could not find passenger in elevator "<<id<<endl;
    return Passenger();
}

void Elevator::removePassenger(int id){
    for(int i=0; i<int(passengers.size()); ++i){
        if(id==passengers[i].getId()){
            passengers.erase(passengers.begin() + i);
            return;
        }
    }
    cout<<"This passenger is not in elevator "<<id<<endl;
}

bool Elevator::isFloorRequest(int floorNumber){
    for(int i=0; i<int(requests.size()); ++i){
        if(requests[i].getRequestType()=="elevator"&&requests[i].getFloorNumber()==floorNumber){
            return true;
        }
    }
    return false;
}

bool Elevator::isElevatorRequest(int floorNumber, string direction){
    for(int i=0; i<int(requests.size()); ++i){
        if(requests[i].getRequestType()=="floor"&&requests[i].getFloorNumber()==floorNumber&&requests[i].getDirection()==direction){
            return true;
        }
    }
    return false;
}

bool Elevator::isPassengerInElevator(int id){
    for(int i=0; i<int(passengers.size()); ++i){
        if(id==passengers[i].getId()){
            return true;
        }
    }
    return false;
}

bool& Elevator::doorsOpen(){
    return doorOpen;
}

bool& Elevator::doorsClosing(){
    return doorClosing;
}

bool& Elevator::moving(){
    return isMoving;
}

bool& Elevator::isHelpButtonPressed(){
    return helpButtonPressed;
}

int Elevator::getDoorObstacleCount(){
    return doorObstacleCount;
}

void Elevator::openDoorSequence(){

    if(doorObstacle){
        doorObstacle=false;
        doorObstacleCount=doorObstacleCount+1;
        cout<<"Closing doors"<<endl;
        displayMessage = "Closing doors";
    }
    else if(doorClosing){
        doorOpen=false;
        doorClosing = false;

        proscessing_request = false;
        cout<<"Doors closed"<<endl;
        displayMessage = "Doors closed";
        doorObstacleCount=0;
        if(requests.size()==0){
           this->direction="idle";
        }
    }
    else if(doorOpen){
        doorClosing = true;
        cout<<"Closing doors"<<endl;
        displayMessage = "Closing doors";
    }
}


void Elevator::moveToNextRequest(){
    int requestFloorNumber = requests[0].getFloorNumber();
    if(direction=="up"){

        if (floorNumber < requestFloorNumber) {
            floorNumber++;
            cout<<floorNumber<<endl;
            displayMessage = "Moving up";
        } else {
            if(doorOpen==false){
                isMoving = false;
                proscessing_request = false;
                requests.erase(requests.begin());
                doorOpen=true;
                cout << "Elevator "<<id<<" arrived at floor"<<floorNumber<<endl;
                cout<<"Open doors"<<endl;
                displayMessage = "Open doors";
            }
            //openDoorSequence();
        }
    }

    else if(direction=="down"){

        if (floorNumber > requestFloorNumber) {
            floorNumber--;
            cout<<floorNumber<<endl;
            displayMessage = "Moving down";
        } else {
            if(doorOpen==false){
                isMoving = false;
                proscessing_request = false;
                requests.erase(requests.begin());
                doorOpen=true;
                cout << "Elevator "<<id<<" arrived at floor"<<floorNumber<<endl;
                cout<<"Open doors"<<endl;
                displayMessage = "Open doors";
            }
            //openDoorSequence();
        }
    }
}


void Elevator::moveToSafeFloor(){
    if (floorNumber > 1) {
        floorNumber--;
    }
    else{
        isMoving = false;
        doorOpen=true;
        doorClosing = false;
        doorObstacle=false;
        cout << "Elevator "<<id<<" arrived at floor"<<floorNumber<<endl;
        cout<<"Open doors"<<endl;
        displayMessage = "Open doors get out of elevator";
    }
}

string& Elevator::getEmergencyDisplayMessage(){
    return emergencyDisplay;
}

void Elevator::helpButtonEmergencySequence(int random_number){

    if(random_number==1){
        if(emergencyDisplay=="Help me!"){
            emergencyDisplay="Help is on the way";
        }
        else{
            emergencyDisplay="Help me!";
        }
    }
    else if(random_number==2){
        if(emergencyDisplay=="Help me!"){
            emergencyDisplay="Calling 911";
        }
        else{
            emergencyDisplay="Help me!";
        }
    }
    else if(random_number==3){
        if(emergencyDisplay=="Hello you need help?"){
            emergencyDisplay="Calling 911";
        }
        else{
            emergencyDisplay="Help me!";
        }
    }
}

void Elevator::clearRequest(){
    requests.clear();
}
