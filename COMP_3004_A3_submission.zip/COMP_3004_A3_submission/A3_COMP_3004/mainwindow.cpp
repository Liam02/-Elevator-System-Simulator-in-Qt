
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Request.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    ECS(2, 5),  // Initialize ElevatorControlSystem with 2 elevators
    passengers{Passenger(1, 105), Passenger(2, 170), Passenger(3, 220), Passenger(4, 135)}
{
    for(int i=0; i<4;++i){
        int r = rand() % 5;
        ECS.getFloor(r).receivePassenger(passengers[i]);
    }
    ui->setupUi(this);

    connect(ui->Test_fire_alarm, &QPushButton::clicked, this, [=]() { ECS.handleFireEmergency(); });
    connect(ui->E1_fire_alarm, &QPushButton::clicked, this, [=]() { ECS.pulllFireAlarm(1); });
    connect(ui->E2_fire_alarm, &QPushButton::clicked, this, [=]() { ECS.pulllFireAlarm(2); });

    connect(ui->Test_power_outage, &QPushButton::clicked, this, [=]() { ECS.handlePowerOutage(); });

    connect(ui->E1_test_overload, &QPushButton::clicked, this, [=]() { ECS.overloadDetected(1); });
    connect(ui->E2_test_overload, &QPushButton::clicked, this, [=]() { ECS.overloadDetected(2); });

    connect(ui->E1_help_button, &QPushButton::clicked, this, [=]() { ECS.handleHelpButtonEmergency(1);  helpButtonPressed(1); });
    connect(ui->E2_help_button, &QPushButton::clicked, this, [=]() { ECS.handleHelpButtonEmergency(2);  helpButtonPressed(2); });

    QList<QPushButton*> buttons = {
            ui->upButton_floor1, ui->upButton_floor2, ui->downButton_floor2,
            ui->upButton_floor3, ui->downButton_floor3, ui->upButton_floor4,
            ui->downButton_floor4, ui->downButton_floor5,
            ui->E1_floor1, ui->E1_floor2, ui->E1_floor3, ui->E1_floor4,
            ui->E1_floor5, ui->E2_floor1, ui->E2_floor2, ui->E2_floor3,
            ui->E2_floor4, ui->E2_floor5, ui->E1_openDoors, ui->E1_closeDoors,
            ui->E2_openDoors, ui->E2_closeDoors
        };

        // Floor 1
        connect(ui->upButton_floor1, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestUp(1); });

        // Floor 2
        connect(ui->upButton_floor2, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestUp(2); });
        connect(ui->downButton_floor2, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestDown(2); });

        // Floor 3
        connect(ui->upButton_floor3, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestUp(3); });
        connect(ui->downButton_floor3, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestDown(3); });

        // Floor 4
        connect(ui->upButton_floor4, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestUp(4); });
        connect(ui->downButton_floor4, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestDown(4); });

        // Floor 5
        connect(ui->downButton_floor5, &QPushButton::clicked, this, [=]() { ECS.makeElevatorRequestDown(5); });


        connect(ui->P1_enter, &QPushButton::clicked, this, [=]() { ECS.handleEnterElevator(1); });
        connect(ui->P1_exit, &QPushButton::clicked, this, [=]() { ECS.handleExitElevator(1); });

        connect(ui->P2_enter, &QPushButton::clicked, this, [=]() { ECS.handleEnterElevator(2); });
        connect(ui->P2_exit, &QPushButton::clicked, this, [=]() { ECS.handleExitElevator(2); });

        connect(ui->P3_enter, &QPushButton::clicked, this, [=]() { ECS.handleEnterElevator(3); });
        connect(ui->P3_exit, &QPushButton::clicked, this, [=]() { ECS.handleExitElevator(3); });

        connect(ui->P4_enter, &QPushButton::clicked, this, [=]() { ECS.handleEnterElevator(4); });
        connect(ui->P4_exit, &QPushButton::clicked, this, [=]() { ECS.handleExitElevator(4); });


        connect(ui->E1_floor1, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(1, 1); });
        connect(ui->E1_floor2, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(2, 1); });
        connect(ui->E1_floor3, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(3, 1); });
        connect(ui->E1_floor4, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(4, 1); });
        connect(ui->E1_floor5, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(5, 1); });

        connect(ui->E2_floor1, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(1, 2); });
        connect(ui->E2_floor2, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(2, 2); });
        connect(ui->E2_floor3, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(3, 2); });
        connect(ui->E2_floor4, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(4, 2); });
        connect(ui->E2_floor5, &QPushButton::clicked, this, [=]() { ECS.makeFloorRequest(5, 2); });

        connect(ui->E1_openDoors, &QPushButton::clicked, this, [=]() { ECS.openDoorButtonPressed(1); });
        connect(ui->E1_closeDoors, &QPushButton::clicked, this, [=]() { ECS.closeDoorButtonPressed(1); });

        connect(ui->E2_openDoors, &QPushButton::clicked, this, [=]() { ECS.openDoorButtonPressed(2); });
        connect(ui->E2_closeDoors, &QPushButton::clicked, this, [=]() { ECS.closeDoorButtonPressed(2); });


    QTimer* timer1 = new QTimer(this);
    connect(timer1, &QTimer::timeout, this, &MainWindow::proscessElevatorRequests);

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_floorDisplay->setText("Floor: "+QString::number(ECS.getElevator(0).getFloorNumber())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_floorDisplay->setText("Floor: "+QString::number(ECS.getElevator(1).getFloorNumber())); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_display->setText(QString::fromStdString(ECS.getElevator(0).getDisplayMessage())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_display->setText(QString::fromStdString(ECS.getElevator(1).getDisplayMessage())); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_display->setStyleSheet(ECS.getFireEmergency()||ECS.getPowerOutage()||ECS.getElevator(0).isHelpButtonPressed() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_display->setStyleSheet(ECS.getFireEmergency()||ECS.getPowerOutage()||ECS.getElevator(1).isHelpButtonPressed() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_emergency_display->setText(QString::fromStdString(ECS.getElevator(0).getEmergencyDisplayMessage())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_emergency_display->setText(QString::fromStdString(ECS.getElevator(1).getEmergencyDisplayMessage())); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_emergency_display->setStyleSheet(ECS.getElevator(0).isHelpButtonPressed() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_emergency_display->setStyleSheet(ECS.getElevator(1).isHelpButtonPressed() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->Test_power_outage->setStyleSheet(ECS.getPowerOutage() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->Test_fire_alarm->setStyleSheet(ECS.getFireEmergency() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_fire_alarm->setStyleSheet(ECS.getFireEmergency() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_fire_alarm->setStyleSheet(ECS.getFireEmergency() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_test_overload->setStyleSheet(ECS.getElevator(0).getOverloadDetected() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_test_overload->setStyleSheet(ECS.getElevator(1).getOverloadDetected() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });


    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_help_button->setStyleSheet(ECS.getElevator(0).isHelpButtonPressed() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_help_button->setStyleSheet(ECS.getElevator(1).isHelpButtonPressed() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });


    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_passengers->setText(QString::fromStdString(ECS.getElevator(0).listPassengers())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_passengers->setText(QString::fromStdString(ECS.getElevator(1).listPassengers())); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->F1_passengers->setText(QString::fromStdString(ECS.getFloor(0).listPassengers())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->F2_passengers->setText(QString::fromStdString(ECS.getFloor(1).listPassengers())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->F3_passengers->setText(QString::fromStdString(ECS.getFloor(2).listPassengers())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->F4_passengers->setText(QString::fromStdString(ECS.getFloor(3).listPassengers())); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->F5_passengers->setText(QString::fromStdString(ECS.getFloor(4).listPassengers())); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_obstacle->setStyleSheet(ECS.getElevator(0).doorObstacleDetected() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_obstacle->setStyleSheet(ECS.getElevator(1).doorObstacleDetected() ? "background-color: red; color: black;" : "background-color: white; color: black;"); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_floor1->setStyleSheet(ECS.getElevator(0).isFloorRequest(1) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_floor2->setStyleSheet(ECS.getElevator(0).isFloorRequest(2) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_floor3->setStyleSheet(ECS.getElevator(0).isFloorRequest(3) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_floor4->setStyleSheet(ECS.getElevator(0).isFloorRequest(4) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_floor5->setStyleSheet(ECS.getElevator(0).isFloorRequest(5) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_floor1->setStyleSheet(ECS.getElevator(1).isFloorRequest(1) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_floor2->setStyleSheet(ECS.getElevator(1).isFloorRequest(2) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_floor3->setStyleSheet(ECS.getElevator(1).isFloorRequest(3) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_floor4->setStyleSheet(ECS.getElevator(1).isFloorRequest(4) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_floor5->setStyleSheet(ECS.getElevator(1).isFloorRequest(5) ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });

    // Floor 1
    connect(timer1, &QTimer::timeout, this, [=]() { ui->upButton_floor1->setStyleSheet(ECS.getElevator(0).isElevatorRequest(1, "up")||ECS.getElevator(1).isElevatorRequest(1, "up") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });

    // Floor 2
    connect(timer1, &QTimer::timeout, this, [=]() { ui->upButton_floor2->setStyleSheet(ECS.getElevator(0).isElevatorRequest(2, "up")||ECS.getElevator(1).isElevatorRequest(2, "up") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->downButton_floor2->setStyleSheet(ECS.getElevator(0).isElevatorRequest(2, "down")||ECS.getElevator(1).isElevatorRequest(2, "down") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });

    // Floor 3
    connect(timer1, &QTimer::timeout, this, [=]() { ui->upButton_floor3->setStyleSheet(ECS.getElevator(0).isElevatorRequest(3, "up")||ECS.getElevator(1).isElevatorRequest(3, "up") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->downButton_floor3->setStyleSheet(ECS.getElevator(0).isElevatorRequest(3, "down")||ECS.getElevator(1).isElevatorRequest(3, "down") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });

    // Floor 4
    connect(timer1, &QTimer::timeout, this, [=]() { ui->upButton_floor4->setStyleSheet(ECS.getElevator(0).isElevatorRequest(4, "up")||ECS.getElevator(1).isElevatorRequest(4, "up") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });
    connect(timer1, &QTimer::timeout, this, [=]() { ui->downButton_floor4->setStyleSheet(ECS.getElevator(0).isElevatorRequest(4, "down")||ECS.getElevator(1).isElevatorRequest(4, "down") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });

    // Floor 5
    connect(timer1, &QTimer::timeout, this, [=]() { ui->downButton_floor5->setStyleSheet(ECS.getElevator(0).isElevatorRequest(5, "down")||ECS.getElevator(1).isElevatorRequest(5, "down") ? "background-color: yellow; color: black;" : "background-color: white; color: black;"); });

    connect(timer1, &QTimer::timeout, this, [=]() { for(auto button:buttons){button->setEnabled(!ECS.getFireEmergency()&&!ECS.getPowerOutage());} ;});

    connect(timer1, &QTimer::timeout, this, [=]() { ui->E1_test_overload->setEnabled(ECS.getElevator(0).isThereAPassengerInElevator()&&ECS.getElevator(0).doorsOpen());});
    connect(timer1, &QTimer::timeout, this, [=]() { ui->E2_test_overload->setEnabled(ECS.getElevator(1).isThereAPassengerInElevator()&&ECS.getElevator(1).doorsOpen());});

    timer1->start(100); // Run every 100 ms (0.1 second)
}

// Define checkElevatorRequests function
void MainWindow::proscessElevatorRequests() {

    for(int i=0; i<2; ++i){
        if((ECS.getFireEmergency()||ECS.getPowerOutage()||ECS.getElevator(i).isHelpButtonPressed()) && !ECS.getElevator(i).proscessingRequest() && (!ECS.getElevator(i).doorsOpen())){

            ECS.getElevator(i).proscessingRequest()=true;
            QTimer* timer2 = new QTimer(this);
            connect(timer2, &QTimer::timeout, this, [=]() {

                ECS.getElevator(i).moveToSafeFloor();
                if (ECS.getElevator(i).doorsOpen()) {
                    timer2->stop();
                    timer2->deleteLater();
                }
            });
            timer2->start(5000);
        }

        else if(!ECS.getElevator(i).proscessingRequest() && ECS.getElevator(i).moving() == false && ECS.getElevator(i).doorsOpen()){
            ECS.getElevator(i).proscessingRequest()=true;
            QTimer* timer2 = new QTimer(this);
            connect(timer2, &QTimer::timeout, this, [=]() {

                if((ECS.getFireEmergency()||ECS.getPowerOutage()||ECS.getElevator(i).isHelpButtonPressed()) && ECS.getElevator(i).getFloorNumber()==1){
                    ECS.getElevator(i).moveToSafeFloor();
                    timer2->stop();
                    timer2->deleteLater();
                }
                else if(!ECS.getElevator(i).getOverloadDetected()){
                    ECS.getElevator(i).openDoorSequence();
                }

                if (!ECS.getElevator(i).doorsOpen()) {
                    timer2->stop();
                    timer2->deleteLater();
                }
            });

            timer2->start(5000);
        }
        else if(!ECS.getElevator(i).proscessingRequest() && ECS.getElevator(i).hasRequest()) {
            ECS.getElevator(i).proscessingRequest()=true;
            ECS.getElevator(i).moving() = true;

            QTimer* timer2 = new QTimer(this);
            connect(timer2, &QTimer::timeout, this, [=]() {

                if(ECS.getFireEmergency()||ECS.getPowerOutage()||ECS.getElevator(i).isHelpButtonPressed()){
                    timer2->stop();
                    timer2->deleteLater();
                }
                else{
                    ECS.getElevator(i).moveToNextRequest();

                    if (ECS.getElevator(i).doorsOpen()) {
                        timer2->stop();
                        timer2->deleteLater();
                    }
                }
            });

            timer2->start(5000);
        }
    }
}

void MainWindow::helpButtonPressed(int elevator_id){

    if(ECS.getElevator(elevator_id-1).isHelpButtonPressed()){
        int random_number = 1 + rand() % 3;
        QTimer* timer2 = new QTimer(this);
        connect(timer2, &QTimer::timeout, this, [=]() {
            if (ECS.getElevator(elevator_id-1).getEmergencyDisplayMessage()=="Calling 911"||ECS.getElevator(elevator_id-1).getEmergencyDisplayMessage()=="Help is on the way"||!ECS.getElevator(elevator_id-1).isHelpButtonPressed()) {
                timer2->stop();
                timer2->deleteLater();
            }
            else{
                ECS.getElevator(elevator_id-1).helpButtonEmergencySequence(random_number);
            }
        });
        timer2->start(5000);
    }
}


MainWindow::~MainWindow()
{
    delete ui;
}
