#include "ElevatorControlSystem.h"

ElevatorControlSystem::ElevatorControlSystem(int numElevators, int numFloors){
    for(int i=0; i<numElevators; ++i){
        elevators.push_back(new Elevator(i+1));
    }
    for (int i=0; i<numFloors; ++i){
         floors.push_back(new Floor(i+1));
    }
    fireEmergency=false;
    powerOutage=false;
}

void ElevatorControlSystem::makeElevatorRequestUp(int floorNumber){
    if(floors[floorNumber-1]->isThereAPassengerOnFloor()){
        Request request = Request("floor", "up", floorNumber);
        assignElevator(request);
        cout<<"Elevator request up made"<<endl;
    }
    else{
        cout <<"There's no passengers on this floor"<<endl;
    }
}

void ElevatorControlSystem::makeElevatorRequestDown(int floorNumber){
    if(floors[floorNumber-1]->isThereAPassengerOnFloor()){
        Request request = Request("floor", "down", floorNumber);
        assignElevator(request);
        cout<<"Elevator request down made"<<endl;
    }
    else{
        cout <<"There's no passengers on this floor"<<endl;
    }
}


void ElevatorControlSystem::makeFloorRequest(int floorNumber, int elevator_id){
    if(elevators[elevator_id-1]->isThereAPassengerInElevator()&&!elevators[elevator_id-1]->isHelpButtonPressed()){
        if(elevators[elevator_id-1]->getDirection()=="idle"){
            if(floorNumber>elevators[elevator_id-1]->getFloorNumber()){
                Request request = Request("elevator", "up", floorNumber);
                elevators[elevator_id-1]->addRequest(request);
            }
            else if(floorNumber<elevators[elevator_id-1]->getFloorNumber()){
                Request request = Request("elevator", "down", floorNumber);
                elevators[elevator_id-1]->addRequest(request);
            }
        }
        else if(elevators[elevator_id-1]->getDirection()=="up"){
            if(floorNumber>elevators[elevator_id-1]->getFloorNumber()){
                Request request = Request("elevator", "up", floorNumber);
                elevators[elevator_id-1]->addRequest(request);
            }
            else{
                cout<<"Elevator "<<elevator_id<<" is moving up, can not request a lower floor"<<endl;
                elevators[elevator_id-1]->getDisplayMessage() = "The elevator is moving up, can not request a lower floor";
            }
        }
        else if(elevators[elevator_id-1]->getDirection()=="down"){
            if(floorNumber<elevators[elevator_id-1]->getFloorNumber()){
                Request request = Request("elevator", "down", floorNumber);
                elevators[elevator_id-1]->addRequest(request);
            }
            else{
                cout<<"Elevator "<<elevator_id<<" is moving down, can not request a higher floor"<<endl;
                elevators[elevator_id-1]->getDisplayMessage() = "The elevator is moving down, can not request a higher floor";
            }
        }
    }
    else{
        cout<<"No passengers in elevator"<<elevator_id<<endl;
    }
}

void ElevatorControlSystem::openDoorButtonPressed(int elevator_id){
    if(elevators[elevator_id-1]->isThereAPassengerInElevator()){
        if(!elevators[elevator_id-1]->moving()){
            elevators[elevator_id-1]->doorsClosing() = false;
            cout<<"Open doors"<<endl;
            elevators[elevator_id-1]->getDisplayMessage() = "Open doors";
            elevators[elevator_id-1]->doorsOpen() = true;
        }
    }
}
void ElevatorControlSystem::closeDoorButtonPressed(int elevator_id){
    if(elevators[elevator_id-1]->isThereAPassengerInElevator()){
        if(!elevators[elevator_id-1]->moving()){
            elevators[elevator_id-1]->doorsClosing() = true;
            cout<<"Closing doors"<<endl;
            elevators[elevator_id-1]->getDisplayMessage() = "Closing doors";
        }
    }
}

void ElevatorControlSystem::assignElevator(Request request){
    if(request.getRequestType()=="floor"){
        int closest_elevator=-1;
        bool requestAdded = false;
        if(request.getDirection()=="up"){
            for(int i = 0; i<int(elevators.size()); ++i){
                if(elevators[i]->isHelpButtonPressed()){
                }
                else if(elevators[i]->getDirection()=="idle"){
                    if(closest_elevator==-1){
                        closest_elevator=i;
                    }
                    else{
                        if(abs(elevators[closest_elevator]->getFloorNumber()-request.getFloorNumber())>abs(elevators[i]->getFloorNumber()-request.getFloorNumber())){
                            closest_elevator=i;
                        }
                    }
                }
                else if(request.getFloorNumber()>=elevators[i]->getFloorNumber() and elevators[i]->getDirection()=="up"){
                    elevators[i]->addRequest(request);
                    requestAdded = true;
                    cout<<"Elevator "<<i+1<<" assigned!"<<endl;
                    break;
                }
            }
            if(closest_elevator!=-1 && requestAdded==false){
                elevators[closest_elevator]->addRequest(request);
                requestAdded = true;
                cout<<"Elevator "<<closest_elevator+1<<" assigned!"<<endl;
            }
        }
        else if(request.getDirection()=="down"){
            for(int i = 0; i<int(elevators.size()); ++i){
                if(elevators[i]->isHelpButtonPressed()){
                }
                else if(elevators[i]->getDirection()=="idle"){
                    if(closest_elevator==-1){
                        closest_elevator=i;
                    }
                    else{
                        if(abs(elevators[closest_elevator]->getFloorNumber()-request.getFloorNumber())>abs(elevators[i]->getFloorNumber()-request.getFloorNumber())){
                            closest_elevator=i;
                        }
                    }
                }
                else if(request.getFloorNumber()<=elevators[i]->getFloorNumber() and elevators[i]->getDirection()=="down"){
                    elevators[i]->addRequest(request);
                    requestAdded = true;
                    cout<<"Elevator "<<i+1<<" assigned!"<<endl;
                    break;
                }
            }
            if(closest_elevator!=-1 && requestAdded==false){
                elevators[closest_elevator]->addRequest(request);
                requestAdded = true;
                cout<<"Elevator "<<closest_elevator+1<<" assigned!"<<endl;
            }
        }
        if(!requestAdded){
            cout <<"All elevators are busy"<<endl;
        }
    }
}

Elevator& ElevatorControlSystem::getElevator(int index){
    return *elevators[index];
}

Floor& ElevatorControlSystem::getFloor(int index){
    return *floors[index];
}

bool& ElevatorControlSystem::getFireEmergency(){
    return fireEmergency;
}

bool& ElevatorControlSystem::getPowerOutage(){
    return powerOutage;
}

void ElevatorControlSystem::overloadDetected(int elevator_id){
    elevators[elevator_id-1]->getOverloadDetected()=!elevators[elevator_id-1]->getOverloadDetected();
    elevators[elevator_id-1]->doorsClosing()=false;
    elevators[elevator_id-1]->getDisplayMessage() = "Overload detected, remove weight";
}

void ElevatorControlSystem::handleEnterElevator(int id){
    bool entered_elevator = false;
    bool passengerOnFloor = false;
    for(int i=0; i<int(floors.size()); ++i){
        if(floors[i]->isPassengerOnFloor(id)){
            passengerOnFloor = true;
            for(int j=0; j<int(elevators.size()); ++j){
                if(elevators[j]->getFloorNumber()==i+1 && elevators[j]->doorsOpen() && !elevators[j]->isHelpButtonPressed()){
                    elevators[j]->receivePassenger(floors[i]->findPassenger(id));
                    floors[i]->removePassenger(id);
                    cout<<"Passenger "<<id<<" entered elevator"<<endl;
                    entered_elevator=true;

                    if(elevators[j]->doorsClosing()){
                        elevators[j]->doorObstacleDetected()=true;
                        cout<<"Door obstacle detected"<<endl;
                        cout<<"Open doors"<<endl;
                        elevators[j]->getDisplayMessage() = "Open doors";
                        if(elevators[j]->getDoorObstacleCount()>=2){
                            elevators[j]->getDisplayMessage() = "Get out of the way of the door";
                        }
                    }
                    break;
                }
            }
            break;
        }
    }
    if(!passengerOnFloor){
        cout<<"Passenger "<<id<<" is not on a floor"<<endl;
    }
    else if(!entered_elevator){
        cout<<"There is no elevator for passenger "<<id<<" to enter"<<endl;
    }
}

void ElevatorControlSystem::handleExitElevator(int id){
    for(int i=0; i<int(elevators.size()); ++i){
        if(elevators[i]->isPassengerInElevator(id)){
            if(elevators[i]->doorsOpen()){
                floors[elevators[i]->getFloorNumber()-1]->receivePassenger(elevators[i]->findPassenger(id));
                elevators[i]->removePassenger(id);
                cout<<"Passenger "<<id<<" exited elevator"<<endl;

                if(elevators[i]->doorsClosing()){
                    elevators[i]->doorObstacleDetected()=true;
                    cout<<"Door obstacle detected"<<endl;
                    cout<<"Open doors"<<endl;
                    elevators[i]->getDisplayMessage() = "Open doors";
                    if(elevators[i]->getDoorObstacleCount()>=2){
                        elevators[i]->getDisplayMessage() = "Get out of the way of the door";
                    }
                }
                break;
            }
        }
    }
}

void ElevatorControlSystem::pulllFireAlarm(int elevator_id){
    if(elevators[elevator_id-1]->isThereAPassengerInElevator() && !fireEmergency){
        handleFireEmergency();
    }
}

void ElevatorControlSystem::handleFireEmergency(){
    fireEmergency=!fireEmergency;
    if(fireEmergency){
        for(int i=0; i<int(elevators.size()); ++i){
            elevators[i]->clearRequest();
            elevators[i]->getDisplayMessage() = "Fire emergency moving to floor 1";
            elevators[i]->proscessingRequest()=false;
        }
    }
    else{
        for(int i=0; i<int(elevators.size()); ++i){
            elevators[i]->proscessingRequest()=false;
        }
    }
}

void ElevatorControlSystem::handlePowerOutage(){
    powerOutage=!powerOutage;
    if(powerOutage){
        for(int i=0; i<int(elevators.size()); ++i){
            elevators[i]->clearRequest();
            elevators[i]->getDisplayMessage() = "Power outage moving to floor 1";
            elevators[i]->proscessingRequest()=false;
        }
    }
    else{
        for(int i=0; i<int(elevators.size()); ++i){
            elevators[i]->proscessingRequest()=false;
        }
    }
}

void ElevatorControlSystem::handleHelpButtonEmergency(int elevator_id){
    if(elevators[elevator_id-1]->isThereAPassengerInElevator() && !elevators[elevator_id-1]->isHelpButtonPressed()){
        elevators[elevator_id-1]->isHelpButtonPressed()=true;
        if(elevators[elevator_id-1]->isHelpButtonPressed()){
            elevators[elevator_id-1]->clearRequest();
            elevators[elevator_id-1]->getDisplayMessage() = "Help emergency";
            elevators[elevator_id-1]->proscessingRequest()=false;
        }
    }
    else if(elevators[elevator_id-1]->isHelpButtonPressed()){
        elevators[elevator_id-1]->isHelpButtonPressed()=false;
        elevators[elevator_id-1]->getEmergencyDisplayMessage()="";
        elevators[elevator_id-1]->proscessingRequest()=false;
    }
}
