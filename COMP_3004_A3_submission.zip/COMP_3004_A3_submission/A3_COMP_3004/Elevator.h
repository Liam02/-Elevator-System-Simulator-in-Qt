#ifndef ELEVATOR_H
#define ELEVATOR_H

#include <string>
#include "Request.h"
using namespace std;
#include <vector>
#include <iostream>
#include "Passenger.h"

class Elevator{

private:
    int id;
    bool isMoving;
    int weightCapacity;
    int currentWeight;
    string direction; // "up", "down", or "idle"
    string displayMessage;
    string emergencyDisplay;
    int floorNumber;

    bool doorOpen;
    bool doorClosing;
    bool proscessing_request;
    bool doorObstacle;
    bool overloadDetected;
    bool helpButtonPressed;
    int doorObstacleCount;

    vector<Request> requests;
    vector<Passenger> passengers;

public:

    Elevator(int id);

    void receivePassenger(Passenger passengers);
    void removePassenger(int id);
    bool isPassengerInElevator(int id);

    Passenger findPassenger(int id);
    string listPassengers();

    void openDoorSequence();
    void clearRequest();
    void helpButtonEmergencySequence(int random_number);

    void moveToSafeFloor();

    bool isFloorRequest(int floorNumber);
    bool isElevatorRequest(int floorNumber, string direction);

    void addRequest(Request request);
    bool hasRequest();
    bool isThereAPassengerInElevator();
    void moveToNextRequest();

    //Elevator getElevator(){return *this;};

    //getters/setters
    string& getDisplayMessage();
    string& getEmergencyDisplayMessage();
    bool& doorsOpen();
    bool& doorsClosing();
    bool& doorObstacleDetected();
    bool& moving();
    bool& getOverloadDetected();
    bool& isHelpButtonPressed();
    int getDoorObstacleCount();
    int getFloorNumber();
    string getDirection();
    bool& proscessingRequest();
};

#endif // ELEVATOR_H
