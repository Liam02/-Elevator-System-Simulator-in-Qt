#ifndef FLOOR_H
#define FLOOR_H
#include "Passenger.h"
#include <QMainWindow>
using namespace std;
#include <vector>
#include <iostream>


class Floor {
private:
    int floorNumber;
    vector<Passenger> passengers;

public:
    Floor(int floorNumber);
    void receivePassengers(vector<Passenger> passengers);
    void receivePassenger(Passenger passenger);
    void removePassenger(int id);
    Passenger findPassenger(int id);
    string listPassengers();

    bool isThereAPassengerOnFloor();
    bool isPassengerOnFloor(int id);
};


#endif // FLOOR_H
