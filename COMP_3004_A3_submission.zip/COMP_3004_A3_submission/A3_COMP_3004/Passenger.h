#ifndef PASSENGER_H
#define PASSENGER_H


class Passenger {
private:
    int id;
    int weight;
    bool isInElevator;

public:

    Passenger();
    Passenger(int id, int weight);
    int getId();
};

#endif // PASSENGER_H
