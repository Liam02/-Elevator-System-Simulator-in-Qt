#ifndef ELEVATORCONTROLSYSTEM_H
#define ELEVATORCONTROLSYSTEM_H

#include <string>
#include "Request.h"
#include "Elevator.h"
using namespace std;
#include <vector>
#include <iostream>
#include "Floor.h"

class ElevatorControlSystem {
private:
    vector<Elevator*> elevators;
    vector<Floor*> floors;
    bool fireEmergency;
    bool powerOutage;

public:
    ElevatorControlSystem(int numElevators, int numFloors);
    void assignElevator(Request request);
    Elevator& getElevator(int index);
    Floor& getFloor(int index);
    void handleEnterElevator(int id);
    void handleExitElevator(int id);
    void openDoorButtonPressed(int elevator_id);
    void closeDoorButtonPressed(int elevator_id);
    void pulllFireAlarm(int elevator_id);
    void overloadDetected(int elevator_id);

    void makeElevatorRequestUp(int floorNumber);
    void makeElevatorRequestDown(int floorNumber);
    void makeFloorRequest(int floorNumber, int elevator_id);

    void handleHelpButtonEmergency(int elevator_id);
    void handleFireEmergency();
    void handlePowerOutage();

    bool& getFireEmergency();
    bool& getPowerOutage();
};

#endif // ELEVATORCONTROLSYSTEM_H
