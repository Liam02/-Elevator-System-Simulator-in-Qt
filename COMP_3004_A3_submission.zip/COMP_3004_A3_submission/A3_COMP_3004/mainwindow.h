#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include "ElevatorControlSystem.h"
#include "Floor.h"
#include <QTimer>
#include "Passenger.h"
#include <random>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void proscessElevatorRequests();
    void helpButtonPressed(int elevator_id);

private:
    Ui::MainWindow *ui;
    ElevatorControlSystem ECS;  // The main control system for the elevators
    std::vector<Passenger> passengers;
    std::vector<Floor> floors;
};
#endif // MAINWINDOW_H
