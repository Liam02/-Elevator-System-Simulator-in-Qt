#ifndef REQUEST_H
#define REQUEST_H

#include <string>
using namespace std;

class Request {
private:
    string requestType;  // "elevator" or "floor"
    string direction; // "up" or "down" or "idle"
    int floorNumber;

public:
    Request();
    Request(string requestType, string direction, int floorNumber);
    string getRequestType();
    string getDirection();
    int getFloorNumber();
};

#endif // REQUEST_H
