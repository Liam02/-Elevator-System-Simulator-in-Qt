#include "Request.h"
#include "ElevatorControlSystem.h"

Request::Request(){
    this->direction = "idle";
}

Request::Request(std::string requestType, std::string direction, int floorNumber){
    this->requestType = requestType;
    this->direction = direction;
    this->floorNumber = floorNumber;
}

string Request::getRequestType(){
    return this->requestType;
}

string Request::getDirection(){
    return this->direction;
}

int Request::getFloorNumber(){
    return this->floorNumber;
}
