#include "Passenger.h"

Passenger::Passenger(){
}
Passenger::Passenger(int id, int weight){
    this->id = id;
    this->weight = weight;
}

int Passenger::getId(){
    return id;
}
