#include "Floor.h"
#include "Request.h"
#include <QMainWindow>
#include <QPushButton>

Floor::Floor(int floorNumber){
    this->floorNumber = floorNumber;
}

void Floor::receivePassengers(vector<Passenger> passengers){
    this->passengers = passengers;
}

void Floor::receivePassenger(Passenger passenger){
    this->passengers.push_back(passenger);
}

string Floor::listPassengers(){
    string passengersList="Passengers: ";
    for(int i=0; i<int(passengers.size()); ++i){
        passengersList = passengersList+"P"+to_string(passengers[i].getId())+", ";
    }
    return passengersList;
}

Passenger Floor::findPassenger(int id){
    for(int i=0; i<int(passengers.size()); ++i){
        if(id==passengers[i].getId()){
            return passengers[i];
        }
    }
    cout<<"Could not find passenger on floor "<<id<<endl;
    return Passenger();
}

void Floor::removePassenger(int id){
    for(int i=0; i<int(passengers.size()); ++i){
        if(id==passengers[i].getId()){
            passengers.erase(passengers.begin()+i);
        }
    }
}


bool Floor::isThereAPassengerOnFloor(){
    return passengers.size()!=0;
}

bool Floor::isPassengerOnFloor(int id){
    for(int i=0; i<int(passengers.size()); ++i){
        if(id==passengers[i].getId()){
            return true;
        }
    }
    return false;
}


