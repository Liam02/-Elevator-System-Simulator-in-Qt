Name: Liam Scoles
Student number: 101269754


Everything not code related can be found in COMP 3004 A3 PDF including the video.

Video link: https://www.youtube.com/watch?v=UWL7A5ZotY8

The code is in A3_COMP_3004 folder, it has everything you need.